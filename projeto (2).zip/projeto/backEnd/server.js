const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promis");

const app= express();

app.use(express.json());

