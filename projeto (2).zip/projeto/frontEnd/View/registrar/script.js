$(document).ready(function () {

    
    $(".register-container")
        .hide()
        .fadeIn(1200);

    $("#btnCadastrar").click(function () {

        let nome = $("#nome").val();
        let email = $("#email").val();
        let senha = $("#senha").val();
        let confirmar = $("#confirmarSenha").val();

        $("#mensagem").hide();

       
        if (nome === "" || email === "" || senha === "" || confirmarSenha === "") {

            $("#mensagem")
                .removeClass("sucesso")
                .addClass("erro")
                .text("Preencha todos os campos")
                .fadeIn(500);

            $(".register-container")
                .animate({ marginLeft: "-10px" }, 100)
                .animate({ marginLeft: "10px" }, 100)
                .animate({ marginLeft: "-10px" }, 100)
                .animate({ marginLeft: "10px" }, 100)
                .animate({ marginLeft: "0px" }, 100);

        
        } else if (senha !== confirmarSenha) {

            $("#mensagem")
                .removeClass("sucesso")
                .addClass("erro")
                .text("As senhas não coincidem")
                .fadeIn(500);

            $(".register-container")
                .animate({ marginLeft: "-10px" }, 100)
                .animate({ marginLeft: "10px" }, 100)
                .animate({ marginLeft: "-10px" }, 100)
                .animate({ marginLeft: "10px" }, 100)
                .animate({ marginLeft: "0px" }, 100);

        
        } else {

            $("#mensagem")
                .removeClass("erro")
                .addClass("sucesso")
                .text("Cadastro realizado com sucesso!")
                .fadeIn(500);

            $("#btnCadastrar")
                .text("Cadastrando...")
                .slideUp(200)
                .slideDown(200);

            
        }

    });

    
    $("#btnVoltar").click(function () {
        window.location.href = "../login/login.html";
    });

});