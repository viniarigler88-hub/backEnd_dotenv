$(document).ready(function() {
    $(".login-container").fadeIn(1200);

    $("#btnlogin").click(function () {
        let email = $("#email").val();
        let senha = $("#senha").val();

        $("#mensagem").hide();

        if(email === "" || senha === "") {
            $("#mensagem")
            .removeClass("sucesso")
            .addClass("erro")
            .text("Preencha todos os campos")
            .fadeIn(500)

            $(".login-container")
            .animate({marginLeft: "-10px"}, 100)
            .animate({marginLeft: "10px"}, 100)
            .animate({marginLeft: "-10px"}, 100)
            .animate({marginLeft: "10px"}, 100)
            .animate({marginLeft: "0px"}, 100);
     
        } else {
            $("#mensagem")
                 .removeClass("erro")
                 .addClass("sucesso")
                 .text("Login Realizado com sucesso!")
                 .fadeIn(500);

                 $("#btnlogin")
                      .text("Entrando...")
                      .slideUp(200)
                      .slideDown(200)


                  
        }
    });



})

function navRegistrar() {
    window.location.href = "../registrar/registrar.html";
}